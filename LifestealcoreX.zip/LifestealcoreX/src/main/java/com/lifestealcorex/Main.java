package com.lifestealcorex;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

public class Main extends JavaPlugin {

    private DatabaseManager databaseManager;
    private PlayerDataManager playerDataManager;
    private HeartManager heartManager;
    private CombatManager combatManager;
    private ReviveManager reviveManager;
    private ScoreboardManager scoreboardManager;
    private TabManager tabManager;
    private GUIManager guiManager;
    private CommandManager commandManager;
    private HeartItemManager heartItemManager;

    @Override
    public void onEnable() {
        // Save default config files
        saveDefaultConfig();
        saveResource("guis.yml", false);

        // Initialize Managers
        databaseManager = new DatabaseManager(this);
        playerDataManager = new PlayerDataManager(this);
        heartManager = new HeartManager(this);
        combatManager = new CombatManager(this);
        reviveManager = new ReviveManager(this);
        scoreboardManager = new ScoreboardManager(this);
        tabManager = new TabManager(this);
        guiManager = new GUIManager(this);
        commandManager = new CommandManager(this);
        heartItemManager = new HeartItemManager(this);

        // Register Events
        getServer().getPluginManager().registerEvents(combatManager, this);
        getServer().getPluginManager().registerEvents(guiManager, this);
        getServer().getPluginManager().registerEvents(new ItemUseListener(this), this);

        // Register internal listener for player joins/quits
        getServer().getPluginManager().registerEvents(new org.bukkit.event.Listener() {
            @org.bukkit.event.EventHandler
            public void onJoin(org.bukkit.event.player.PlayerJoinEvent e) {
                playerDataManager.loadPlayer(e.getPlayer());
                scoreboardManager.createScoreboard(e.getPlayer());
            }

            @org.bukkit.event.EventHandler
            public void onQuit(org.bukkit.event.player.PlayerQuitEvent e) {
                playerDataManager.unloadPlayer(e.getPlayer());
                scoreboardManager.removeScoreboard(e.getPlayer());
            }
        }, this);

        // Register Commands
        getCommand("lifesteal").setExecutor(commandManager);
        getCommand("hearts").setExecutor(commandManager);
        getCommand("withdrawheart").setExecutor(commandManager);
        getCommand("revive").setExecutor(commandManager);

        // Hook PlaceholderAPI — register our standalone expansion so %lifesteal_*% placeholders work
        if (Bukkit.getPluginManager().getPlugin("PlaceholderAPI") != null) {
            new LifestealExpansion(this).register();
            getLogger().info("PlaceholderAPI found - LifestealCoreX placeholders registered!");
        } else {
            getLogger().warning("PlaceholderAPI not found! Placeholders will not work.");
        }

        getLogger().info("LifestealCoreX has been enabled successfully!");
    }

    @Override
    public void onDisable() {
        playerDataManager.saveAll();
        databaseManager.close();
        getLogger().info("LifestealCoreX has been disabled.");
    }

    public DatabaseManager getDatabaseManager() { return databaseManager; }
    public PlayerDataManager getPlayerDataManager() { return playerDataManager; }
    public HeartManager getHeartManager() { return heartManager; }
    public CombatManager getCombatManager() { return combatManager; }
    public ReviveManager getReviveManager() { return reviveManager; }
    public ScoreboardManager getScoreboardManager() { return scoreboardManager; }
    public TabManager getTabManager() { return tabManager; }
    public GUIManager getGUIManager() { return guiManager; }
    public HeartItemManager getHeartItemManager() { return heartItemManager; }
}
