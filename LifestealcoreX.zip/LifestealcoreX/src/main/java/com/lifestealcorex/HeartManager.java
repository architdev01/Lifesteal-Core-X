package com.lifestealcorex;

import org.bukkit.BanList;
import org.bukkit.Bukkit;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import net.kyori.adventure.text.Component;
import java.time.Instant;
import java.util.Date;
import java.util.UUID;

public class HeartManager {
    private final Main plugin;

    public HeartManager(Main plugin) {
        this.plugin = plugin;
    }

    public void updatePlayerHealth(Player player, int hearts) {
        AttributeInstance maxHealth = player.getAttribute(Attribute.GENERIC_MAX_HEALTH);
        if (maxHealth != null) {
            maxHealth.setBaseValue(hearts * 2.0); // 1 heart = 2 health
            if (player.getHealth() > maxHealth.getBaseValue()) {
                player.setHealth(maxHealth.getBaseValue());
            }
        }
    }

    public void addHearts(Player player, int amount) {
        UUID uuid = player.getUniqueId();
        PlayerDataManager.PlayerStats stats = plugin.getPlayerDataManager().getStats(uuid);
        if (stats == null)
            return;

        int maxHearts = plugin.getConfig().getInt("max-hearts", 20);
        stats.hearts = Math.min(stats.hearts + amount, maxHearts);

        updatePlayerHealth(player, stats.hearts);
        plugin.getPlayerDataManager().savePlayer(player);
    }

    public void removeHearts(Player player, int amount) {
        UUID uuid = player.getUniqueId();
        PlayerDataManager.PlayerStats stats = plugin.getPlayerDataManager().getStats(uuid);
        if (stats == null)
            return;

        int minHearts = plugin.getConfig().getInt("min-hearts", 0);
        stats.hearts = Math.max(stats.hearts - amount, minHearts);

        updatePlayerHealth(player, stats.hearts);
        plugin.getPlayerDataManager().savePlayer(player);

        if (stats.hearts <= 0 && plugin.getConfig().getBoolean("ban-on-zero-hearts", true)) {
            banPlayer(player);
        }
    }

    public void setHearts(Player player, int amount) {
        UUID uuid = player.getUniqueId();
        PlayerDataManager.PlayerStats stats = plugin.getPlayerDataManager().getStats(uuid);
        if (stats == null)
            return;

        stats.hearts = amount;
        updatePlayerHealth(player, stats.hearts);
        plugin.getPlayerDataManager().savePlayer(player);

        if (stats.hearts <= 0 && plugin.getConfig().getBoolean("ban-on-zero-hearts", true)) {
            banPlayer(player);
        }
    }

    public void banPlayer(Player player) {
        plugin.getServer().getBanList(BanList.Type.NAME).addBan(
                player.getName(),
                "§cYou have lost all your hearts!",
                null,
                "LifestealCoreX");
        player.kickPlayer("§cYou have run out of hearts and are banned from this SMP!");
    }

    public void withdrawHearts(Player player, int amount) {
        UUID uuid = player.getUniqueId();
        PlayerDataManager.PlayerStats stats = plugin.getPlayerDataManager().getStats(uuid);
        if (stats == null)
            return;

        int minHearts = plugin.getConfig().getInt("min-hearts", 0);
        if (stats.hearts - amount <= minHearts) {
            player.sendMessage("§cYou cannot withdraw that many hearts! You need at least " + (minHearts + 1)
                    + " hearts to survive.");
            return;
        }

        removeHearts(player, amount);

        ItemStack heartItem = plugin.getGUIManager().createGuiItem(
                org.bukkit.Material.valueOf(plugin.getConfig().getString("heart-item-material", "CLOCK")),
                plugin.getConfig().getString("heart-item-name", "&c\u2764 Heart").replace("&", "§"));
        heartItem.setAmount(amount);

        if (!player.getInventory().addItem(heartItem).isEmpty()) {
            player.getWorld().dropItem(player.getLocation(), heartItem);
        }
        player.sendMessage("§aYou have withdrawn " + amount + " heart(s)!");
    }
}
