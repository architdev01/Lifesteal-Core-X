package com.lifestealcorex;

import org.bukkit.Bukkit;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

public class DatabaseManager {
    private final Main plugin;
    private final boolean useMySQL;
    private Connection connection;

    public DatabaseManager(Main plugin) {
        this.plugin = plugin;
        this.useMySQL = plugin.getConfig().getString("database.type", "YAML").equalsIgnoreCase("MYSQL");
        
        if (useMySQL) {
            connectMySQL();
            createTables();
        } else {
            // Using YAML - data is handled in PlayerDataManager or separate files
            // For simplicity, we might just save to players.yml
            plugin.getLogger().info("Using YAML for database storage.");
        }
    }

    private void connectMySQL() {
        String host = plugin.getConfig().getString("database.host");
        int port = plugin.getConfig().getInt("database.port");
        String database = plugin.getConfig().getString("database.database");
        String username = plugin.getConfig().getString("database.username");
        String password = plugin.getConfig().getString("database.password");

        try {
            connection = DriverManager.getConnection(
                    "jdbc:mysql://" + host + ":" + port + "/" + database + "?useSSL=false&autoReconnect=true",
                    username, password);
            plugin.getLogger().info("Connected to MySQL database.");
        } catch (SQLException e) {
            plugin.getLogger().severe("Failed to connect to MySQL! Check config.");
            e.printStackTrace();
        }
    }

    private void createTables() {
        if (!useMySQL || connection == null) return;
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try (PreparedStatement ps = connection.prepareStatement(
                    "CREATE TABLE IF NOT EXISTS lifesteal_players (" +
                    "uuid VARCHAR(36) PRIMARY KEY, " +
                    "name VARCHAR(16), " +
                    "hearts INT, " +
                    "kills INT, " +
                    "deaths INT, " +
                    "playtime BIGINT" +
                    ")")) {
                ps.executeUpdate();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        });
    }

    public CompletableFuture<Void> savePlayerStatsAsync(UUID uuid, String name, int hearts, int kills, int deaths, long playtime) {
        if (!useMySQL) {
            // Setup YAML save logic in a separate file if needed
            return CompletableFuture.completedFuture(null);
        }

        return CompletableFuture.runAsync(() -> {
            try (PreparedStatement ps = connection.prepareStatement(
                    "INSERT INTO lifesteal_players (uuid, name, hearts, kills, deaths, playtime) " +
                    "VALUES (?, ?, ?, ?, ?, ?) " +
                    "ON DUPLICATE KEY UPDATE name = ?, hearts = ?, kills = ?, deaths = ?, playtime = ?")) {
                ps.setString(1, uuid.toString());
                ps.setString(2, name);
                ps.setInt(3, hearts);
                ps.setInt(4, kills);
                ps.setInt(5, deaths);
                ps.setLong(6, playtime);
                ps.setString(7, name);
                ps.setInt(8, hearts);
                ps.setInt(9, kills);
                ps.setInt(10, deaths);
                ps.setLong(11, playtime);
                ps.executeUpdate();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        });
    }

    public CompletableFuture<PlayerDataManager.PlayerStats> loadPlayerStatsAsync(UUID uuid) {
        if (!useMySQL) {
            return CompletableFuture.completedFuture(null);
        }

        return CompletableFuture.supplyAsync(() -> {
            try (PreparedStatement ps = connection.prepareStatement("SELECT * FROM lifesteal_players WHERE uuid = ?")) {
                ps.setString(1, uuid.toString());
                ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    return new PlayerDataManager.PlayerStats(
                            rs.getString("name"),
                            rs.getInt("hearts"),
                            rs.getInt("kills"),
                            rs.getInt("deaths"),
                            rs.getLong("playtime")
                    );
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
            return null;
        });
    }

    public void close() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public boolean isMySQL() {
        return useMySQL;
    }
}
