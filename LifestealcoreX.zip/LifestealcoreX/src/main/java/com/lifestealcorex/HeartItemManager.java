package com.lifestealcorex;

import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.Arrays;
import java.util.Random;

public class HeartItemManager {
    private final Main plugin;
    private final Random random = new Random();

    private final NamespacedKey tierKey;
    private final NamespacedKey heartsKey;

    public HeartItemManager(Main plugin) {
        this.plugin = plugin;
        this.tierKey = new NamespacedKey(plugin, "heart_tier");
        this.heartsKey = new NamespacedKey(plugin, "heart_amount");
    }

    public void dropRandomHeart(Player victim, Player killer) {
        int t1Chance = plugin.getConfig().getInt("heart-drops.tier1.chance", 60);
        int t2Chance = plugin.getConfig().getInt("heart-drops.tier2.chance", 30);
        int t3Chance = plugin.getConfig().getInt("heart-drops.tier3.chance", 10);

        int total = t1Chance + t2Chance + t3Chance;
        int rand = random.nextInt(total);

        int tier;
        int hearts;
        String name;

        if (rand < t1Chance) {
            tier = 1;
            hearts = plugin.getConfig().getInt("heart-drops.tier1.hearts", 1);
            name = plugin.getConfig().getString("heart-drops.tier1.name", "&c\u2764 Heart Fragment");
        } else if (rand < t1Chance + t2Chance) {
            tier = 2;
            hearts = plugin.getConfig().getInt("heart-drops.tier2.hearts", 2);
            name = plugin.getConfig().getString("heart-drops.tier2.name", "&c\u2764\u2764 Heart Core");
        } else {
            tier = 3;
            hearts = plugin.getConfig().getInt("heart-drops.tier3.hearts", 3);
            name = plugin.getConfig().getString("heart-drops.tier3.name", "&4\u2764\u2764\u2764 Heart Relic");
        }

        ItemStack heartItem = createTieredHeart(tier, hearts, name.replace("&", "\u00a7"));
        victim.getWorld().dropItemNaturally(victim.getLocation(), heartItem);

        String killMsg = plugin.getConfig().getString("messages.kill", "&c%killer% has stolen a Tier %tier% Heart from %victim%!")
                .replace("&", "\u00a7")
                .replace("%killer%", killer != null ? killer.getName() : "Unknown")
                .replace("%victim%", victim.getName())
                .replace("%tier%", String.valueOf(tier));

        if (killer != null) {
            killer.sendMessage(killMsg);
        }
        victim.sendMessage(killMsg);
    }

    private ItemStack createTieredHeart(int tier, int hearts, String name) {
        ItemStack item = new ItemStack(Material.CLOCK);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(name);
            meta.setLore(Arrays.asList(
                    "\u00a77Right click to consume",
                    "\u00a77Grants \u00a7c+" + hearts + " Hearts"
            ));

            PersistentDataContainer container = meta.getPersistentDataContainer();
            container.set(tierKey, PersistentDataType.INTEGER, tier);
            container.set(heartsKey, PersistentDataType.INTEGER, hearts);

            item.setItemMeta(meta);
        }
        return item;
    }

    public boolean isTieredHeart(ItemStack item) {
        if (item == null || item.getType() != Material.CLOCK || !item.hasItemMeta()) return false;
        PersistentDataContainer container = item.getItemMeta().getPersistentDataContainer();
        return container.has(tierKey, PersistentDataType.INTEGER);
    }

    public int getHeartAmount(ItemStack item) {
        if (!isTieredHeart(item)) return 0;
        PersistentDataContainer container = item.getItemMeta().getPersistentDataContainer();
        return container.getOrDefault(heartsKey, PersistentDataType.INTEGER, 0);
    }

    public int getTier(ItemStack item) {
        if (!isTieredHeart(item)) return 0;
        PersistentDataContainer container = item.getItemMeta().getPersistentDataContainer();
        return container.getOrDefault(tierKey, PersistentDataType.INTEGER, 0);
    }

    /**
     * Plays the full-screen Totem of Undying animation.
     * Uses the Paper/CraftBukkit approach of sending the entity event packet 
     * directly to the player to force the first-person totem screen.
     */
    public void playTotemEffect(Player player) {
        try {
            // Send the entity status packet (status 35 = totem animation) directly to the player
            // This is the correct way to trigger the first-person totem screen in Paper
            Object craftPlayerHandle = player.getClass().getMethod("getHandle").invoke(player);
            Object connection = craftPlayerHandle.getClass().getField("connection").get(craftPlayerHandle);

            // Create ClientboundEntityEventPacket with status 35 (TOTEM_RESURRECT)
            Class<?> packetClass = Class.forName("net.minecraft.network.protocol.game.ClientboundEntityEventPacket");
            Class<?> entityClass = Class.forName("net.minecraft.world.entity.Entity");
            Object packet = packetClass.getDeclaredConstructor(entityClass, byte.class)
                    .newInstance(craftPlayerHandle, (byte) 35);

            connection.getClass().getMethod("send", Class.forName("net.minecraft.network.protocol.Packet"))
                    .invoke(connection, packet);
        } catch (Exception e) {
            // Fallback: use the Bukkit API method which at minimum shows to nearby players
            player.playEffect(org.bukkit.EntityEffect.TOTEM_RESURRECT);
        }

        // Play sound
        player.playSound(player.getLocation(), Sound.ITEM_TOTEM_USE, 1.0f, 1.0f);

        // Spawn totem particles around the player
        player.getWorld().spawnParticle(Particle.TOTEM_OF_UNDYING, player.getLocation().add(0, 1, 0), 80, 0.4, 0.8, 0.4, 0.2);

        // Glowing effect for 2 seconds
        player.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, 40, 1, false, false, false));
    }
}
