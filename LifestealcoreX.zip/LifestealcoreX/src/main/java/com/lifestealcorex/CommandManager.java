package com.lifestealcorex;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class CommandManager implements CommandExecutor {
    private final Main plugin;

    public CommandManager(Main plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("§cOnly players can run these commands.");
            return true;
        }

        Player player = (Player) sender;
        String cmdName = command.getName().toLowerCase();

        switch (cmdName) {
            case "lifesteal":
                if (args.length == 0) {
                    plugin.getGUIManager().openMainGUI(player);
                    return true;
                }

                if (args[0].equalsIgnoreCase("admin")) {
                    if (!player.hasPermission("lifestealcorex.admin")) {
                        player.sendMessage("§cYou do not have permission.");
                        return true;
                    }
                    plugin.getGUIManager().openAdminGUI(player);
                    return true;
                }

                if (args[0].equalsIgnoreCase("reload") && player.hasPermission("lifestealcorex.admin")) {
                    plugin.reloadConfig();
                    // In a full implementation, you'd reload other configs here too
                    player.sendMessage("§aLifestealCoreX reloaded.");
                    return true;
                }
                
                // Example of admin sub-commands: /lifesteal sethearts <player> <amount>
                if (args[0].equalsIgnoreCase("sethearts") && args.length == 3 && player.hasPermission("lifestealcorex.admin")) {
                    Player target = Bukkit.getPlayer(args[1]);
                    if (target != null) {
                        try {
                            int amount = Integer.parseInt(args[2]);
                            plugin.getHeartManager().setHearts(target, amount);
                            player.sendMessage("§aSet " + target.getName() + "'s hearts to " + amount);
                        } catch (NumberFormatException e) {
                            player.sendMessage("§cInvalid number.");
                        }
                    } else {
                        player.sendMessage("§cPlayer not found.");
                    }
                    return true;
                }

                if (args[0].equalsIgnoreCase("addhearts") && args.length == 3 && player.hasPermission("lifestealcorex.admin")) {
                    Player target = Bukkit.getPlayer(args[1]);
                    if (target != null) {
                        try {
                            int amount = Integer.parseInt(args[2]);
                            plugin.getHeartManager().addHearts(target, amount);
                            player.sendMessage("§aAdded " + amount + " hearts to " + target.getName());
                        } catch (NumberFormatException e) {
                            player.sendMessage("§cInvalid number.");
                        }
                    } else {
                        player.sendMessage("§cPlayer not found.");
                    }
                    return true;
                }

                if (args[0].equalsIgnoreCase("removehearts") && args.length == 3 && player.hasPermission("lifestealcorex.admin")) {
                    Player target = Bukkit.getPlayer(args[1]);
                    if (target != null) {
                        try {
                            int amount = Integer.parseInt(args[2]);
                            plugin.getHeartManager().removeHearts(target, amount);
                            player.sendMessage("§aRemoved " + amount + " hearts from " + target.getName());
                        } catch (NumberFormatException e) {
                            player.sendMessage("§cInvalid number.");
                        }
                    } else {
                        player.sendMessage("§cPlayer not found.");
                    }
                    return true;
                }
                
                if (args[0].equalsIgnoreCase("help")) {
                    player.sendMessage("§8§m--------------------------------");
                    player.sendMessage("§c§lLIFESTEAL CORE X §8- §7Commands");
                    player.sendMessage("§8§m--------------------------------");
                    player.sendMessage("§c/lifesteal §8- §7Open Main GUI");
                    player.sendMessage("§c/withdrawheart <amount> §8- §7Withdraw hearts to items");
                    player.sendMessage("§c/revive <player> §8- §7Revive a banned player");
                    if (player.hasPermission("lifestealcorex.admin")) {
                        player.sendMessage("");
                        player.sendMessage("§c§lAdmin Commands:");
                        player.sendMessage("§e/lifesteal admin §8- §7Open Admin GUI");
                        player.sendMessage("§e/lifesteal reload §8- §7Reload Plugin configs");
                        player.sendMessage("§e/lifesteal sethearts <player> <amount>");
                        player.sendMessage("§e/lifesteal addhearts <player> <amount>");
                        player.sendMessage("§e/lifesteal removehearts <player> <amount>");
                    }
                    player.sendMessage("§8§m--------------------------------");
                    return true;
                }
                
                break;

            case "hearts":
                plugin.getGUIManager().openHeartsGUI(player);
                break;

            case "withdrawheart":
                if (args.length == 1) {
                    try {
                        int amount = Integer.parseInt(args[0]);
                        if (amount > 0) {
                            plugin.getHeartManager().withdrawHearts(player, amount);
                        } else {
                            player.sendMessage("§cMust be > 0.");
                        }
                    } catch (NumberFormatException e) {
                        player.sendMessage("§cInvalid number.");
                    }
                } else {
                    player.sendMessage("§cUsage: /withdrawheart <amount>");
                }
                break;

            case "revive":
                if (args.length == 1) {
                    plugin.getReviveManager().revivePlayer(player, args[0]);
                } else {
                    player.sendMessage("§cUsage: /revive <player>");
                }
                break;
        }

        return true;
    }
}
