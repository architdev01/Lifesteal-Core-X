package com.lifestealcorex;

import me.clip.placeholderapi.PlaceholderAPI;
import net.luckperms.api.LuckPerms;
import net.luckperms.api.LuckPermsProvider;
import net.luckperms.api.model.user.User;
import net.luckperms.api.cacheddata.CachedMetaData;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;

import java.util.List;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class ScoreboardManager {
    private final Main plugin;
    private final ConcurrentHashMap<UUID, Scoreboard> playerScoreboards = new ConcurrentHashMap<>();
    private boolean luckPermsPresent;

    public ScoreboardManager(Main plugin) {
        this.plugin = plugin;
        this.luckPermsPresent = Bukkit.getPluginManager().getPlugin("LuckPerms") != null;

        if (!plugin.getConfig().getBoolean("scoreboard.enabled", true)) {
            plugin.getLogger().info("Scoreboard is disabled in config.yml.");
            return;
        }

        startUpdateTask();
    }

    public void createScoreboard(Player player) {
        if (!plugin.getConfig().getBoolean("scoreboard.enabled", true)) return;

        Scoreboard board = Bukkit.getScoreboardManager().getNewScoreboard();
        String title = TabManager.translateHexCodes(
                plugin.getConfig().getString("scoreboard.title", "&c&lLIFESTEAL SMP"));
        Objective obj = board.registerNewObjective("lifestealx", "dummy",
            net.kyori.adventure.text.Component.text(title));
        obj.setDisplaySlot(DisplaySlot.SIDEBAR);

        player.setScoreboard(board);
        playerScoreboards.put(player.getUniqueId(), board);
        updateScoreboard(player);
    }

    public void removeScoreboard(Player player) {
        playerScoreboards.remove(player.getUniqueId());
        player.setScoreboard(Bukkit.getScoreboardManager().getMainScoreboard());
    }

    private void updateScoreboard(Player player) {
        Scoreboard board = playerScoreboards.get(player.getUniqueId());
        if (board == null) return;

        Objective obj = board.getObjective("lifestealx");
        if (obj == null) return;

        List<String> lines = plugin.getConfig().getStringList("scoreboard.lines");

        // Clear old scores
        for (String entry : board.getEntries()) {
            board.resetScores(entry);
        }

        int score = lines.size();
        for (String line : lines) {
            String text = line;

            // Replace LuckPerms placeholders directly via API
            String rankPrefix = getRankPrefix(player);
            String rankGroup = getRankGroup(player);
            text = text.replace("%luckperms_prefix%", rankPrefix)
                       .replace("%luckperms_primary_group%", rankGroup);

            if (Bukkit.getPluginManager().getPlugin("PlaceholderAPI") != null) {
                text = PlaceholderAPI.setPlaceholders(player, text);
            }

            // Fallback manual replacements
            text = text.replace("%player_name%", player.getName())
                       .replace("%server_online%", String.valueOf(Bukkit.getOnlinePlayers().size()))
                       .replace("%lifesteal_hearts%", getHearts(player));

            // Parse all color codes (hex + legacy)
            text = TabManager.translateHexCodes(text);

            if (text.isEmpty()) {
                text = " ".repeat(score);
            }

            obj.getScore(text).setScore(score);
            score--;
        }
    }

    private String getRankPrefix(Player player) {
        if (!luckPermsPresent) return "";
        try {
            LuckPerms api = LuckPermsProvider.get();
            User user = api.getUserManager().getUser(player.getUniqueId());
            if (user != null) {
                CachedMetaData metaData = user.getCachedData().getMetaData();
                String prefix = metaData.getPrefix();
                return prefix != null ? prefix : "";
            }
        } catch (Exception e) {
            // LuckPerms not loaded
        }
        return "";
    }

    private String getRankGroup(Player player) {
        if (!luckPermsPresent) return "";
        try {
            LuckPerms api = LuckPermsProvider.get();
            User user = api.getUserManager().getUser(player.getUniqueId());
            if (user != null) {
                return user.getPrimaryGroup();
            }
        } catch (Exception e) {
            // LuckPerms not loaded
        }
        return "";
    }

    private String getHearts(Player player) {
        PlayerDataManager.PlayerStats stats = plugin.getPlayerDataManager().getStats(player.getUniqueId());
        return stats != null ? String.valueOf(stats.hearts) : "0";
    }

    private void startUpdateTask() {
        Bukkit.getScheduler().runTaskTimerAsynchronously(plugin, () -> {
            for (Player player : Bukkit.getOnlinePlayers()) {
                updateScoreboard(player);
            }
        }, 20L, 20L);
    }
}
