package com.lifestealcorex;

import me.clip.placeholderapi.PlaceholderAPI;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class GUIManager implements Listener {
    private final Main plugin;
    private FileConfiguration guiConfig;

    public GUIManager(Main plugin) {
        this.plugin = plugin;
        loadConfig();
    }

    private void loadConfig() {
        File file = new File(plugin.getDataFolder(), "guis.yml");
        if (!file.exists()) {
            plugin.saveResource("guis.yml", false);
        }
        guiConfig = YamlConfiguration.loadConfiguration(file);
    }

    public void openMainGUI(Player player) {
        openGUI(player, "main");
    }

    public void openHeartsGUI(Player player) {
        openGUI(player, "hearts");
    }

    public void openAdminGUI(Player player) {
        openGUI(player, "admin");
    }

    private void openGUI(Player player, String guiName) {
        ConfigurationSection section = guiConfig.getConfigurationSection("guis." + guiName);
        if (section == null) return;

        String title = section.getString("title", "&8Menu").replace("&", "§");
        if (Bukkit.getPluginManager().getPlugin("PlaceholderAPI") != null) {
            title = PlaceholderAPI.setPlaceholders(player, title);
        } else {
            title = title.replace("%player_name%", player.getName());
        }

        int size = section.getInt("size", 27);
        Inventory inv = Bukkit.createInventory(null, size, net.kyori.adventure.text.Component.text(title));

        ConfigurationSection items = section.getConfigurationSection("items");
        if (items != null) {
            for (String key : items.getKeys(false)) {
                ConfigurationSection itemSec = items.getConfigurationSection(key);
                if (itemSec == null) continue;

                int slot = itemSec.getInt("slot");
                Material mat = Material.matchMaterial(itemSec.getString("material", "DIRT"));
                String name = itemSec.getString("name", "").replace("&", "§");
                List<String> lore = itemSec.getStringList("lore");

                ItemStack item = new ItemStack(mat != null ? mat : Material.DIRT);
                ItemMeta meta = item.getItemMeta();
                if (meta != null) {
                    if (Bukkit.getPluginManager().getPlugin("PlaceholderAPI") != null) {
                        name = PlaceholderAPI.setPlaceholders(player, name);
                    }
                    meta.setDisplayName(name);

                    if (!lore.isEmpty()) {
                        List<String> formattedLore = new ArrayList<>();
                        for (String l : lore) {
                            String fLore = l.replace("&", "§");
                            if (Bukkit.getPluginManager().getPlugin("PlaceholderAPI") != null) {
                                fLore = PlaceholderAPI.setPlaceholders(player, fLore);
                            }
                            formattedLore.add(fLore);
                        }
                        meta.setLore(formattedLore);
                    }
                    item.setItemMeta(meta);
                }
                inv.setItem(slot, item);
            }
        }

        player.openInventory(inv);
    }

    public ItemStack createGuiItem(Material material, String name, String... lore) {
        ItemStack item = new ItemStack(material, 1);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(name);
            ArrayList<String> metaLore = new ArrayList<>();
            for (String loreComments : lore) {
                metaLore.add(loreComments);
            }
            meta.setLore(metaLore);
            item.setItemMeta(meta);
        }
        return item;
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player)) return;
        Player player = (Player) event.getWhoClicked();

        String invTitle = net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer.plainText().serialize(event.getView().title());
        
        // Very basic title checking - in production, custom holders or NBT tags are safer
        if (invTitle.contains("Menu") || invTitle.contains("Shop") || invTitle.contains("Panel") || invTitle.contains("Stats")) {
            event.setCancelled(true); // Prevent taking items

            ItemStack clicked = event.getCurrentItem();
            if (clicked == null || !clicked.hasItemMeta()) return;

            String itemName = clicked.getItemMeta().getDisplayName();

            // Simple handling based on item names or slots
            if (itemName.contains("Your Hearts")) {
                openHeartsGUI(player);
            } else if (itemName.contains("Withdraw 1 Heart")) {
                player.closeInventory();
                player.performCommand("withdrawheart 1");
            }
            // Add more specific handler checks here...
        }
    }
}
