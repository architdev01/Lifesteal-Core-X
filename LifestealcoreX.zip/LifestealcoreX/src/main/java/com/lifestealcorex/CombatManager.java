package com.lifestealcorex;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;

public class CombatManager implements Listener {
    private final Main plugin;

    public CombatManager(Main plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onPlayerDeath(PlayerDeathEvent event) {
        Player victim = event.getEntity();
        Player killer = victim.getKiller(); // null if killed by mob/fall/environment

        PlayerDataManager.PlayerStats victimStats = plugin.getPlayerDataManager().getStats(victim.getUniqueId());

        if (killer != null && !killer.equals(victim)) {
            // ========== PvP Kill ==========
            // Victim loses hearts
            if (victimStats != null) {
                victimStats.deaths++;
                int lostHearts = plugin.getConfig().getInt("hearts-lost-per-death", 1);
                plugin.getHeartManager().removeHearts(victim, lostHearts);
                plugin.getPlayerDataManager().savePlayer(victim);
            }

            // Killer gets a random tier heart drop
            PlayerDataManager.PlayerStats killerStats = plugin.getPlayerDataManager().getStats(killer.getUniqueId());
            if (killerStats != null) {
                killerStats.kills++;
                plugin.getPlayerDataManager().savePlayer(killer);
                plugin.getHeartItemManager().dropRandomHeart(victim, killer);
            }
        } else {
            // ========== Non-PvP Death (mob, fall, environment) ==========
            // Only update deaths counter — DO NOT remove hearts
            if (victimStats != null) {
                victimStats.deaths++;
                plugin.getPlayerDataManager().savePlayer(victim);
            }
        }
    }
}
