package com.lifestealcorex;

import me.clip.placeholderapi.PlaceholderAPI;
import net.luckperms.api.LuckPerms;
import net.luckperms.api.LuckPermsProvider;
import net.luckperms.api.model.user.User;
import net.luckperms.api.cacheddata.CachedMetaData;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class TabManager {
    private final Main plugin;
    private boolean tabPluginPresent;
    private boolean luckPermsPresent;

    // Matches &#RRGGBB hex color codes
    private static final Pattern HEX_PATTERN = Pattern.compile("&#([A-Fa-f0-9]{6})");

    public TabManager(Main plugin) {
        this.plugin = plugin;
        this.tabPluginPresent = Bukkit.getPluginManager().getPlugin("TAB") != null;
        this.luckPermsPresent = Bukkit.getPluginManager().getPlugin("LuckPerms") != null;

        if (tabPluginPresent) {
            plugin.getLogger().info("TAB plugin detected! LifestealCoreX tablist is disabled.");
        }

        if (!plugin.getConfig().getBoolean("tablist.enabled", true)) {
            plugin.getLogger().info("Tablist is disabled in config.yml.");
            return;
        }

        if (!tabPluginPresent) {
            startUpdateTask();
        }
    }

    private void updateTablist(Player player) {
        String headerStr = plugin.getConfig().getString("tablist.header", "&c&lLifesteal SMP\n&eplay.server.com");
        String footerStr = plugin.getConfig().getString("tablist.footer", "&7Online: &f%server_online%\n&7Hearts: &c%lifesteal_hearts%");
        String formatStr = plugin.getConfig().getString("tablist.player-format", "%luckperms_prefix% &f%player_name% &c\u2764 %lifesteal_hearts%");

        // Replace our custom LuckPerms placeholders BEFORE PAPI runs
        String rankPrefix = getRankPrefix(player);
        String rankGroup = getRankGroup(player);
        headerStr = headerStr.replace("%luckperms_prefix%", rankPrefix).replace("%luckperms_primary_group%", rankGroup);
        footerStr = footerStr.replace("%luckperms_prefix%", rankPrefix).replace("%luckperms_primary_group%", rankGroup);
        formatStr = formatStr.replace("%luckperms_prefix%", rankPrefix).replace("%luckperms_primary_group%", rankGroup);

        if (Bukkit.getPluginManager().getPlugin("PlaceholderAPI") != null) {
            headerStr = PlaceholderAPI.setPlaceholders(player, headerStr);
            footerStr = PlaceholderAPI.setPlaceholders(player, footerStr);
            formatStr = PlaceholderAPI.setPlaceholders(player, formatStr);
        }

        // Fallback manual replacements
        headerStr = headerStr.replace("%player_name%", player.getName())
                             .replace("%server_online%", String.valueOf(Bukkit.getOnlinePlayers().size()))
                             .replace("%lifesteal_hearts%", getHearts(player));
        footerStr = footerStr.replace("%player_name%", player.getName())
                             .replace("%server_online%", String.valueOf(Bukkit.getOnlinePlayers().size()))
                             .replace("%lifesteal_hearts%", getHearts(player));
        formatStr = formatStr.replace("%player_name%", player.getName())
                             .replace("%server_online%", String.valueOf(Bukkit.getOnlinePlayers().size()))
                             .replace("%lifesteal_hearts%", getHearts(player));

        // Parse colors: first hex &#RRGGBB, then &x legacy
        headerStr = translateHexCodes(headerStr);
        footerStr = translateHexCodes(footerStr);
        formatStr = translateHexCodes(formatStr);

        player.sendPlayerListHeaderAndFooter(
                net.kyori.adventure.text.Component.text(headerStr),
                net.kyori.adventure.text.Component.text(footerStr)
        );

        player.playerListName(net.kyori.adventure.text.Component.text(formatStr));
    }

    /**
     * Translates &#RRGGBB hex color codes AND legacy &x codes to Minecraft's \u00a7x\u00a7R\u00a7R\u00a7G\u00a7G\u00a7B\u00a7B format.
     */
    public static String translateHexCodes(String text) {
        // First handle &#RRGGBB
        Matcher matcher = HEX_PATTERN.matcher(text);
        StringBuilder sb = new StringBuilder();
        while (matcher.find()) {
            String hex = matcher.group(1);
            StringBuilder replacement = new StringBuilder("\u00a7x");
            for (char c : hex.toCharArray()) {
                replacement.append("\u00a7").append(c);
            }
            matcher.appendReplacement(sb, replacement.toString());
        }
        matcher.appendTail(sb);

        // Then handle normal &X color codes
        return sb.toString().replace("&", "\u00a7");
    }

    public String getRankPrefix(Player player) {
        if (!luckPermsPresent) return "";
        try {
            LuckPerms api = LuckPermsProvider.get();
            User user = api.getUserManager().getUser(player.getUniqueId());
            if (user != null) {
                CachedMetaData metaData = user.getCachedData().getMetaData();
                String prefix = metaData.getPrefix();
                return prefix != null ? prefix : "";
            }
        } catch (Exception e) {
            // LuckPerms not loaded
        }
        return "";
    }

    public String getRankGroup(Player player) {
        if (!luckPermsPresent) return "";
        try {
            LuckPerms api = LuckPermsProvider.get();
            User user = api.getUserManager().getUser(player.getUniqueId());
            if (user != null) {
                return user.getPrimaryGroup();
            }
        } catch (Exception e) {
            // LuckPerms not loaded
        }
        return "";
    }

    private String getHearts(Player player) {
        PlayerDataManager.PlayerStats stats = plugin.getPlayerDataManager().getStats(player.getUniqueId());
        return stats != null ? String.valueOf(stats.hearts) : "0";
    }

    private void startUpdateTask() {
        Bukkit.getScheduler().runTaskTimerAsynchronously(plugin, () -> {
            for (Player player : Bukkit.getOnlinePlayers()) {
                updateTablist(player);
            }
        }, 20L, 20L);
    }
}
