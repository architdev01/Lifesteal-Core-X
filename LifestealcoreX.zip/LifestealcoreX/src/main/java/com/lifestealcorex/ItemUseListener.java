package com.lifestealcorex;

import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public class ItemUseListener implements Listener {
    private final Main plugin;

    public ItemUseListener(Main plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event) {
        if (event.getAction() != Action.RIGHT_CLICK_AIR && event.getAction() != Action.RIGHT_CLICK_BLOCK) {
            return;
        }

        Player player = event.getPlayer();
        ItemStack item = player.getInventory().getItemInMainHand();

        if (item == null || item.getType() == Material.AIR || !item.hasItemMeta()) {
            return;
        }

        ItemMeta meta = item.getItemMeta();
        if (meta == null || !meta.hasDisplayName()) {
            return;
        }

        String displayName = meta.getDisplayName();
        String heartItemName = plugin.getConfig().getString("heart-item-name", "&c\u2764 Heart").replace("&", "\u00a7");
        String containerItemName = plugin.getConfig().getString("heart-container-name", "&c&lHeart Container").replace("&", "\u00a7");

        if (plugin.getHeartItemManager().isTieredHeart(item)) {
            // ===== Tiered Heart Drop Consumption =====
            event.setCancelled(true);
            int gained = plugin.getHeartItemManager().getHeartAmount(item);
            int tier = plugin.getHeartItemManager().getTier(item);

            int currentHearts = plugin.getPlayerDataManager().getStats(player.getUniqueId()).hearts;
            int maxHearts = plugin.getConfig().getInt("max-hearts", 20);

            if (currentHearts >= maxHearts) {
                player.sendMessage(plugin.getConfig().getString("messages.max-hearts", "&cYou have reached the maximum hearts!").replace("&", "\u00a7"));
                return;
            }

            int actualGain = Math.min(gained, maxHearts - currentHearts);
            int originalAmount = item.getAmount();

            // CRITICAL FIX: Swap to Totem FIRST so client sees it, THEN fire the animation effect
            player.getInventory().setItemInMainHand(new ItemStack(Material.TOTEM_OF_UNDYING));
            player.playEffect(org.bukkit.EntityEffect.TOTEM_RESURRECT);
            player.playSound(player.getLocation(), Sound.ITEM_TOTEM_USE, 1.0f, 1.0f);
            player.getWorld().spawnParticle(Particle.TOTEM_OF_UNDYING, player.getLocation().add(0, 1, 0), 80, 0.4, 0.8, 0.4, 0.2);
            player.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, 40, 1, false, false, false));

            // After 1 tick: consume item and grant hearts
            final int finalGain = actualGain;
            plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
                if (originalAmount > 1) {
                    item.setAmount(originalAmount - 1);
                    player.getInventory().setItemInMainHand(item);
                } else {
                    player.getInventory().setItemInMainHand(null);
                }
                plugin.getHeartManager().addHearts(player, finalGain);
            }, 1L);

            String msg = plugin.getConfig().getString("messages.absorb", "&aYou absorbed a Tier %tier% Heart! (+%hearts% Hearts)")
                    .replace("&", "\u00a7")
                    .replace("%tier%", String.valueOf(tier))
                    .replace("%hearts%", String.valueOf(actualGain));
            player.sendMessage(msg);

        } else if (item.getType() == Material.CLOCK && displayName.equals(heartItemName)) {
            // ===== Regular Heart Item (CLOCK) =====
            event.setCancelled(true);
            int gained = plugin.getConfig().getInt("heart-item-gained", 1);

            int currentHearts = plugin.getPlayerDataManager().getStats(player.getUniqueId()).hearts;
            int maxHearts = plugin.getConfig().getInt("max-hearts", 20);

            if (currentHearts >= maxHearts) {
                player.sendMessage(plugin.getConfig().getString("messages.max-hearts", "&cYou have reached the maximum hearts!").replace("&", "\u00a7"));
                return;
            }

            consumeItem(player, item);
            plugin.getHeartManager().addHearts(player, gained);
            player.sendMessage(plugin.getConfig().getString("messages.consume", "&aYou gained +%hearts% hearts!").replace("&", "\u00a7").replace("%hearts%", String.valueOf(gained)));

        } else if (displayName.equals(containerItemName)) {
            // ===== Heart Container =====
            event.setCancelled(true);
            int gained = plugin.getConfig().getInt("heart-container-gained", 5);

            int currentHearts = plugin.getPlayerDataManager().getStats(player.getUniqueId()).hearts;
            int maxHearts = plugin.getConfig().getInt("max-hearts", 20);

            if (currentHearts >= maxHearts) {
                player.sendMessage(plugin.getConfig().getString("messages.max-hearts", "&cYou have reached the maximum hearts!").replace("&", "\u00a7"));
                return;
            }

            int actualGain = Math.min(gained, maxHearts - currentHearts);
            consumeItem(player, item);
            plugin.getHeartManager().addHearts(player, actualGain);
            player.sendMessage(plugin.getConfig().getString("messages.consume", "&aYou gained +%hearts% hearts!").replace("&", "\u00a7").replace("%hearts%", String.valueOf(actualGain)));
        }
    }

    private void consumeItem(Player player, ItemStack item) {
        if (item.getAmount() > 1) {
            item.setAmount(item.getAmount() - 1);
        } else {
            player.getInventory().setItemInMainHand(null);
        }
    }
}
