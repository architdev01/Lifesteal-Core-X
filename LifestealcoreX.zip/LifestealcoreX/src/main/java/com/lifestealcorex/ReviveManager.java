package com.lifestealcorex;

import org.bukkit.BanList;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class ReviveManager {
    private final Main plugin;

    public ReviveManager(Main plugin) {
        this.plugin = plugin;
    }

    public void revivePlayer(Player sender, String targetName) {
        OfflinePlayer target = plugin.getServer().getOfflinePlayer(targetName);
        
        if (target == null || !target.hasPlayedBefore()) {
            sender.sendMessage("§cPlayer not found.");
            return;
        }

        BanList banList = plugin.getServer().getBanList(BanList.Type.NAME);
        if (!banList.isBanned(target.getName())) {
            sender.sendMessage("§cThis player is not banned.");
            return;
        }

        // Logic check for Revive Crystal item
        ItemStack itemInHand = sender.getInventory().getItemInMainHand();
        String crystalName = plugin.getConfig().getString("revive-crystal-name", "&d&lRevive Crystal").replace("&", "§");

        if (itemInHand.getItemMeta() == null || !itemInHand.getItemMeta().getDisplayName().equals(crystalName)) {
            sender.sendMessage("§cYou must be holding a Revive Crystal to revive someone!");
            return;
        }

        // Consume the crystal
        itemInHand.setAmount(itemInHand.getAmount() - 1);
        
        // Revive Logic
        banList.pardon(target.getName());
        
        // Reset hearts for target (Need async load/save logic for offline)
        if (plugin.getDatabaseManager().isMySQL()) {
            plugin.getDatabaseManager().loadPlayerStatsAsync(target.getUniqueId()).thenAccept(stats -> {
                if (stats != null) {
                    plugin.getDatabaseManager().savePlayerStatsAsync(
                        target.getUniqueId(),
                        target.getName(),
                        plugin.getConfig().getInt("starting-hearts", 10),
                        stats.kills,
                        stats.deaths,
                        stats.playtime
                    );
                }
            });
        } else {
            // Setup YAML logic
            plugin.getPlayerDataManager().resetOfflinePlayerHearts(target.getUniqueId());
        }
        
        sender.sendMessage("§aSuccessfully revived " + targetName + "!");
        plugin.getServer().broadcastMessage("§a" + sender.getName() + " has revived " + targetName + " using a Revive Crystal!");
    }
}
