package com.lifestealcorex;

import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class PlayerDataManager {
    private final Main plugin;
    private final Map<UUID, PlayerStats> playerCache = new HashMap<>();
    private File playersFile;
    private FileConfiguration playersConfig;

    public PlayerDataManager(Main plugin) {
        this.plugin = plugin;
        if (!plugin.getDatabaseManager().isMySQL()) {
            setupYaml();
        }
    }

    private void setupYaml() {
        playersFile = new File(plugin.getDataFolder(), "players.yml");
        if (!playersFile.exists()) {
            try {
                playersFile.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        playersConfig = YamlConfiguration.loadConfiguration(playersFile);
    }

    public void loadPlayer(Player player) {
        UUID uuid = player.getUniqueId();
        if (plugin.getDatabaseManager().isMySQL()) {
            plugin.getDatabaseManager().loadPlayerStatsAsync(uuid).thenAccept(stats -> {
                if (stats != null) {
                    playerCache.put(uuid, stats);
                    plugin.getHeartManager().updatePlayerHealth(player, stats.hearts);
                } else {
                    int startingHearts = plugin.getConfig().getInt("starting-hearts", 10);
                    PlayerStats newStats = new PlayerStats(player.getName(), startingHearts, 0, 0, 0);
                    playerCache.put(uuid, newStats);
                    plugin.getHeartManager().updatePlayerHealth(player, startingHearts);
                }
            });
        } else {
            // Load from YAML
            String path = uuid.toString();
            int startingHearts = plugin.getConfig().getInt("starting-hearts", 10);
            int hearts = playersConfig.getInt(path + ".hearts", startingHearts);
            int kills = playersConfig.getInt(path + ".kills", 0);
            int deaths = playersConfig.getInt(path + ".deaths", 0);
            long playtime = playersConfig.getLong(path + ".playtime", 0);

            PlayerStats stats = new PlayerStats(player.getName(), hearts, kills, deaths, playtime);
            playerCache.put(uuid, stats);
            plugin.getHeartManager().updatePlayerHealth(player, hearts);
        }
    }

    public void savePlayer(Player player) {
        UUID uuid = player.getUniqueId();
        PlayerStats stats = playerCache.get(uuid);
        if (stats == null) return;

        if (plugin.getDatabaseManager().isMySQL()) {
            plugin.getDatabaseManager().savePlayerStatsAsync(uuid, player.getName(), stats.hearts, stats.kills, stats.deaths, stats.playtime);
        } else {
            // Save to YAML
            String path = uuid.toString();
            playersConfig.set(path + ".name", player.getName());
            playersConfig.set(path + ".hearts", stats.hearts);
            playersConfig.set(path + ".kills", stats.kills);
            playersConfig.set(path + ".deaths", stats.deaths);
            playersConfig.set(path + ".playtime", stats.playtime);
            saveYaml();
        }
    }

    public void saveAll() {
        for (Player player : plugin.getServer().getOnlinePlayers()) {
            savePlayer(player);
        }
    }

    private void saveYaml() {
        try {
            playersConfig.save(playersFile);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public PlayerStats getStats(UUID uuid) {
        return playerCache.get(uuid);
    }

    public void unloadPlayer(Player player) {
        savePlayer(player);
        playerCache.remove(player.getUniqueId());
    }

    public void resetOfflinePlayerHearts(UUID uuid) {
        if (plugin.getDatabaseManager().isMySQL()) return;
        
        String path = uuid.toString();
        if (playersConfig.contains(path)) {
            playersConfig.set(path + ".hearts", plugin.getConfig().getInt("starting-hearts", 10));
            saveYaml();
        }
    }

    public static class PlayerStats {
        public String name;
        public int hearts;
        public int kills;
        public int deaths;
        public long playtime; // in milliseconds or ticks

        public PlayerStats(String name, int hearts, int kills, int deaths, long playtime) {
            this.name = name;
            this.hearts = hearts;
            this.kills = kills;
            this.deaths = deaths;
            this.playtime = playtime;
        }
    }
}
