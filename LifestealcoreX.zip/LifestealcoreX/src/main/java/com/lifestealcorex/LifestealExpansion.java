package com.lifestealcorex;

import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.OfflinePlayer;
import org.jetbrains.annotations.NotNull;

public class LifestealExpansion extends PlaceholderExpansion {

    private final Main plugin;

    public LifestealExpansion(Main plugin) {
        this.plugin = plugin;
    }

    @Override
    public @NotNull String getIdentifier() {
        return "lifesteal";
    }

    @Override
    public @NotNull String getAuthor() {
        return plugin.getDescription().getAuthors().isEmpty() ? "LifestealCoreX" : plugin.getDescription().getAuthors().get(0);
    }

    @Override
    public @NotNull String getVersion() {
        return plugin.getDescription().getVersion();
    }

    /**
     * This must return true so PAPI keeps this expansion registered
     * even if the plugin is reloaded.
     */
    @Override
    public boolean persist() {
        return true;
    }

    /**
     * This must return true — it tells PAPI that we don't need to download
     * a separate jar from the PAPI eCloud to work (we are self-contained).
     */
    @Override
    public boolean canRegister() {
        return true;
    }

    @Override
    public String onRequest(OfflinePlayer player, @NotNull String params) {
        if (player == null) return "0";

        PlayerDataManager.PlayerStats stats = plugin.getPlayerDataManager().getStats(player.getUniqueId());
        if (stats == null) return "0";

        switch (params.toLowerCase()) {
            case "hearts":
                return String.valueOf(stats.hearts);
            case "maxhearts":
                return String.valueOf(plugin.getConfig().getInt("max-hearts", 20));
            case "kills":
                return String.valueOf(stats.kills);
            case "deaths":
                return String.valueOf(stats.deaths);
            default:
                return null;
        }
    }
}
